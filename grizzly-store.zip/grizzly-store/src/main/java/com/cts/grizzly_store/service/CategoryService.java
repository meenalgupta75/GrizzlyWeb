package com.cts.grizzly_store.service;

import java.util.List;

import com.cts.grizzly_store.bean.Category;

public interface CategoryService {
public List<Category> getAllCategory();
}
